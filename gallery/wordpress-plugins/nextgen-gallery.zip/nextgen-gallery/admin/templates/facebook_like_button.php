<div id="fb-root"></div>
<div id="ngg_facebook_like" class="fb-like" data-href="http://www.facebook.com/nextgengallery" data-send="false" data-layout="button_count" data-width="450" data-show-faces="false"></div>
