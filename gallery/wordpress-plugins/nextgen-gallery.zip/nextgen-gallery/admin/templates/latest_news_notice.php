<style>
	.ngg_latest_news_notice .wp-pointer-arrow{
		left: 20px;
	}
</style>
<h3>Important Announcement</h3>
<p>We're happy to announce Photocrati has acquired NextGEN Gallery.</p>
<p>
	For more on our plans, visit the new <a target="_blank" href='http://www.nextgen-gallery.com'>NextGEN Gallery website</a>.
	For more on what's included in our first NextGEN Update, see <a target="_blank" href='http://www.nextgen-gallery.com/latest-release-notes'>here</a>.
</p>
<p>
	<?php include('twitter_follow_link.php'); ?>
</p>